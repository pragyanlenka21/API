import { Component } from '@angular/core';
import { TestService } from '../common-service/test.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  products: any[] = [];

  constructor(private productService: TestService) { }

  ngOnInit(): void {
    this.productService.getPostWithObs().subscribe((res: any) => {
      this.products = res.products;
    });

  }
}
